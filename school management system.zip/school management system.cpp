#include <iostream>
using namespace std;

class Student {
public:
    string name;
    string phone;
    string email;
    int level;
    double gpa;
    string index;
};

class Attendance {
public:
    string index;
    int level;
};

int main() {
    int option;
    Student detail[10000];
    int total_student = 4;

    int level, gpa;
    string index, email;
    string name, phone;
    Attendance attendance[10000];

    detail[0] = {"Robert", "0557196527", "rob@uenr.edu", 300, 3.99, "UEB3226722"};
    detail[1] = {"Nyarko", "0543210543", "ama@uenr.edu", 100, 4.00, "UEB2303332"};
    detail[2] = {"Michael", "0123456789", "mike@uenr.edu", 400, 3.47, "UEB4245254"};
    detail[3] = {"Phillip", "9876543210", "phil@uenr.edu", 200, 2.59, "UEB1332442"};

    while (true) {
        cout << "\n------------------ UENR MANAGEMENT SYSTEM ---------------------"
             << "\n---------------------------------------------------------------\n"
             << "\n1. Check Total students"
             << "\n2. Make attendance"
             << "\n3. View all Profiles"
             << "\n4. Add new student"
             << "\n5. Quit"
             << "\nSelect: ";
        cin >> option;

        if (option == 1) {
            cout << "The total number of students: " << total_student << "\n\n";
            cout << "Do you want to see their profiles?"
                 << "\n1. Yes"
                 << "\n2. No"
                 << "\nSelect: ";
            cin >> option;
            
 if (option == 1) {            
for (int i = 0; i < total_student; i++) {
cout << "Name : "<< detail[i].name << "\n"
    "Mail : "<< detail[i].email << "\n" 
    "Phone : "<< detail[i].phone << "\n"
    "GPA : " << detail[i].gpa << "\n" 
    "Index : "<< detail[i].index << "\n" 
    "Level : "<< detail[i].level << endl<<endl;
}
} else if (option != 2) {
                cout << "Invalid choice!";
            }            
            
            
           
              /*  cout << "Name           Mail        Phone      GPA     Index     Level" << endl;
                for (int i = 0; i < total_student; i++) {
                    cout << detail[i].name  <<  "     "  <<  detail[i].email  <<  "     "  <<  detail[i].phone  <<  "     "  <<  detail[i].gpa   <<  "     "  <<  detail[i].index  <<  "     "  <<  detail[i].level  << endl;
             */   
            
} else if (option == 2) {
int count = 0;
            cout << "--------------ATTENDANCE--------------\n";
while (true) {
cout << "Index: ";
cin >> index;
cout << "Level [100 - 400]: ";
cin >> level;
attendance[count].index = index;
attendance[count].level = level;

cout << "Is time up?"
     << "\n1. Yes"
	 << "\n2. No"
     << "\nSelect: ";
cin >> option;
if (option == 1) {
            cout << "   INDEX    ------   LEVEL\n\n";
for (int i = 0; i <= count; i++) {
cout << attendance[i].index << "    " << attendance[i].level << endl;
} 
break;
}
    count++;
}
} else if (option == 3) {
        	for (int i = 0; i < total_student; i++) {
cout << "Name : "<< detail[i].name << "\n"
    "Mail : "<< detail[i].email << "\n" 
    "Phone : "<< detail[i].phone << "\n"
    "GPA : " << detail[i].gpa << "\n" 
    "Index : "<< detail[i].index << "\n" 
    "Level : "<< detail[i].level << endl<<endl;
}
}
     else if (option == 4) {
            cout << "\n\n-------------------- ADD FRESHERS ----------------------\n\n";
            cout << "Enter First name: ";
            cin >> name;
            cout << "Enter index: ";
            cin >> index;
            cout << "Enter phone: ";
            cin >> phone;
            cout << "Enter email: ";
            cin >> email;
            level = 100;
            gpa = 0.0;
            total_student += 1;
            detail[total_student - 1].name = name;
            detail[total_student - 1].index = index;
            detail[total_student - 1].phone = phone;
            detail[total_student - 1].email = email;
            detail[total_student - 1].level = level;
            detail[total_student - 1].gpa = gpa;
       cout << "------------ student added --------\n\a";
       cout << detail[total_student - 1].name << "\n  " 
			<< detail[total_student - 1].email << "\n " 
			<< detail[total_student - 1].phone << "\n "
			<< detail[total_student - 1].gpa << "\n " 
			<< detail[total_student - 1].index << endl;
            
        } else if (option == 5) {
            cout << "\n\n\n\n\n ---------------------- QUIT ------------------------\a";
            break;
        } else {
            cout << "Invalid option\a\a\a";
        }
    }

    return 0;
}
